# Network-Automation-in-Python

Companion repository for the EC-Council Code Red [Network Automation in Python](https://codered.eccouncil.org/course/network-automation-with-python) course.

Network Automation in Python, by EC-Council