# EC Council CodeRed 
## Network Automation in Python
### Section 10.2 Diagrams
Example of using a Python drawing module and Markdown to create striking documentation.