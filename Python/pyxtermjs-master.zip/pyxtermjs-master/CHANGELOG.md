## 0.5.0.2

- support copy and paste in terminal (#27)

## 0.5.0.1

- Do not fail on unicode decode errors
- Cast port argument as an integer

## 0.5.0.0

- Update dependencies xtermjs and socketio
- Turn off flask's logging
- Update setup.py to install from pinned dependencies in requirements.tx
