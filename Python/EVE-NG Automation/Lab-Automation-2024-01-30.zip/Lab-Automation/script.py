a = int(10)
b = int(20)
c = a + b

print(f"Result is: {c}")

if a > b:
    print ("a ++")
else:
    print ("a --")
print("a")    
print (type(c))
