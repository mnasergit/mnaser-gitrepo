import os
print(os.environ['PATH'])
